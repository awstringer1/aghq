library(testthat)
library(aghq)

test_check("aghq")
